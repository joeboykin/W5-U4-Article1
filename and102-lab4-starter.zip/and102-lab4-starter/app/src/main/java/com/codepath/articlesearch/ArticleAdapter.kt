package com.codepath.articlesearch

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

const val ARTICLE_EXTRA = "ARTICLE_EXTRA"
private const val TAG = "ArticleAdapter"

class ArticleAdapter(private val context: Context, val articles: List<Article>) :
    RecyclerView.Adapter<ArticleAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_article, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // TODO: Get the individual article and bind to holder
        val article = articles[position]
        holder.bind(article)
    }


    override fun getItemCount() = articles.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
        View.OnClickListener {

        private val mediaImageView = itemView.findViewById<ImageView>(R.id.mediaImage)
        private val titleTextView: TextView = itemView.findViewById(R.id.mediaTitle)
        private val abstractTextView: TextView = itemView.findViewById(R.id.mediaAbstract)

        init {
            itemView.setOnClickListener(this)
        }

        // TODO: Write a helper method to help set up the onBindViewHolder method
        fun bind(article: Article) {
            val baseUrl = "https://static01.nyt.com/"
            if (article.multimedia.isNullOrEmpty())
                mediaImageView.setImageDrawable(null)
            else
                Glide.with(context).load(baseUrl + article.multimedia[0].url).centerCrop()
                    .into(mediaImageView)
            titleTextView.text = article.headline?.main
            abstractTextView.text = article.abstract
        }




        override fun onClick(v: View?) {
            // TODO: Get selected article

            // TODO: Navigate to Details screen and pass selected article

            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                val article = articles[position]
                val bundle = Bundle()
                bundle.putString("title", article.headline?.main)
                if (!article.multimedia.isNullOrEmpty())
                    bundle.putString("url", article.multimedia[0].url)

                if (!article.byline?.person.isNullOrEmpty())
                    bundle.putString("byline", article.byline?.person?.get(0)?.firstname)
                bundle.putString("abstract", article.abstract)
                val intent = Intent(context, DetailActivity::class.java)
                intent.putExtra("article", bundle)
                context.startActivity(intent)
            }
        }
    }
}