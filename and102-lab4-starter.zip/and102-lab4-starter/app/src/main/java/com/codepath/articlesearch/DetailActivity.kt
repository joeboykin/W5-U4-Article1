package com.codepath.articlesearch

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

private const val TAG = "DetailActivity"

class DetailActivity : AppCompatActivity() {
    private lateinit var mediaImageView: ImageView
    private lateinit var titleTextView: TextView
    private lateinit var bylineTextView: TextView
    private lateinit var abstractTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // TODO: Find the views for the screen
        mediaImageView = findViewById(R.id.mediaImage1)
        titleTextView = findViewById(R.id.mediaTitle1)
        bylineTextView = findViewById(R.id.mediaByline)
        abstractTextView = findViewById(R.id.mediaAbstract1)

        // TODO: Get the extra from the Intent

        val article = intent.getBundleExtra("article")
        // Retrieve the article object from the intent

        val baseUrl = "https://static01.nyt.com/"
        val url = article!!.getString("url")
        if (!url.isNullOrEmpty())
            Glide.with(this).load(baseUrl + url).centerCrop()
                .into(mediaImageView)
        titleTextView.text = article!!.getString("title")
       val byline = article.getString("byline")
        if(!byline.isNullOrEmpty())
        bylineTextView.text =byline
        abstractTextView.text = article.getString("abstract")


    }
}